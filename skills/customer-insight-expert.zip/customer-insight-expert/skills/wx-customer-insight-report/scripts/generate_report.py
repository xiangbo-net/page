#!/usr/bin/env python3
"""
国内客户洞察与售前咨询报告生成器

从 report_data.json + config.json 生成双格式 HTML + MD 报告。

跨平台兼容说明：
  - macOS: python3 generate_report.py data.json config.json ./output
  - Windows: python generate_report.py data.json config.json ./output
  - 所有路径使用 os.path 处理，无需硬编码分隔符
  - 文件名过滤兼容 Windows 非法字符集

Usage:
    python3 generate_report.py <report_data_path> [config_path] [output_dir]

Args:
    report_data_path: AI 生成的报告数据 JSON 路径
    config_path:    用户配置文件路径（可选，默认 WorkBuddy 用户数据目录）
    output_dir:     输出目录（可选，默认当前目录）
"""

import json
import os
import sys
import html as html_module
from datetime import datetime
from tempfile import gettempdir


# ──────────────────────────────
# 跨平台路径工具
# ──────────────────────────────

def default_skill_userdata(*segments):
    """
    返回 WorkBuddy 用户数据目录下的跨平台路径。

    在 macOS 上: ~/.workbuddy/userdata/skill/...
    在 Windows 上: %USERPROFILE%/.workbuddy/userdata/skill/...
    """
    base = os.path.expanduser("~/.workbuddy/userdata/skill")
    return os.path.join(base, *segments)


def read_json(path):
    """读取 JSON 文件，不存在时返回空字典"""
    if not os.path.exists(path):
        print(f"[WARN] 文件不存在: {path}")
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def make_slug(name):
    """从公司名生成合法文件名片段（兼容 Windows + macOS 非法字符集）"""
    for ch in r'\/:*?"<>|':
        name = name.replace(ch, "")
    return name.strip() or "客户报告"


# ──────────────────────────────
# 风险等级工具
# ──────────────────────────────

LEVEL_EMOJI = {"🟢": "🟢", "🟡": "🟡", "🔴": "🔴", "green": "🟢", "yellow": "🟡", "red": "🔴"}
LEVEL_LABEL = {"🟢": "低", "🟡": "中", "🔴": "高"}
LEVEL_COLOR = {"🟢": "#28a745", "🟡": "#ffc107", "🔴": "#dc3545"}
LEVEL_COLOR_LIGHT = {"🟢": "#e6f9ec", "🟡": "#fff8e1", "🔴": "#fce4e4"}
LEVEL_TAG_CLASS = {"🟢": "tag-green", "🟡": "tag-yellow", "🔴": "tag-red"}


def risk_badge(level_emoji):
    """生成风险标识 HTML"""
    emoji = LEVEL_EMOJI.get(level_emoji, level_emoji)
    label = LEVEL_LABEL.get(emoji, "")
    color = LEVEL_COLOR.get(emoji, "#6c757d")
    return f'<span class="risk-badge risk-{emoji}" style="background:{color}20;color:{color};border:1px solid {color}40;">{emoji} {label}</span>'


# ──────────────────────────────
# Markdown 生成
# ──────────────────────────────

def render_md(data, my_company):
    """生成 Markdown 格式报告（12 章结构）"""
    lines = []
    c = data.get("company_name", "目标公司")
    cm = data.get("cover_meta", {})
    subtitle = cm.get("subtitle", "")
    report_id = cm.get("report_id", "")
    my_name = my_company.get("name", "") if my_company else ""

    # 封面
    lines.append(f"# {c} 客户洞察与售前咨询报告\n")
    if subtitle:
        lines.append(f"> *{subtitle}*\n")
    lines.append(f"> **生成时间**：{datetime.now().strftime('%Y-%m-%d %H:%M')}")
    if report_id:
        lines.append(f"> **报告编号**：{report_id}")
    if my_name:
        lines.append(f"> **编制**：{my_name}")
    lines.append(f"> **数据来源**：{data.get('research_source', 'websearch')}\n")
    lines.append("---\n")

    # 1. 客户概览
    lines.append("## 一、客户概览\n")
    bi = data.get("basic_info", {})
    lines.append("| 项目 | 内容 |")
    lines.append("|------|------|")
    for k, v in bi.items():
        lines.append(f"| {k} | {v} |")
    lines.append("")

    # 2. 股东与集团背景
    lines.append("## 二、股东与集团背景\n")
    lines.append(f"- **股权结构**：{data.get('shareholder_structure', '暂无数据')}")
    lines.append("")

    # 3. 行业与业务分析
    lines.append("## 三、行业与业务分析\n")
    biz = data.get("business", {})
    if isinstance(biz, dict):
        for k, v in biz.items():
            lines.append(f"### {k}\n{v}\n")
    else:
        lines.append(f"{biz}\n")

    # 4. 技术能力评估
    ta = data.get("tech_assessment", [])
    if ta:
        lines.append("## 四、技术能力评估\n")
        lines.append("| 能力维度 | 当前水平 | AI 赋能空间 |")
        lines.append("|----------|:-------:|-----------|")
        for item in ta:
            dim = item.get("dimension", "")
            level = item.get("level", 0)
            max_lv = item.get("max_level", 5)
            space = item.get("ai_space", "")
            stars = "★" * level + "☆" * (max_lv - level)
            lines.append(f"| {dim} | {stars} | {space} |")
        lines.append("")

    # 5. SWTO 分析
    lines.append("## 五、SWTO 分析\n")
    swto = data.get("swto", {})
    for title, key in [("优势 (Strengths)", "S"), ("短板 (Weaknesses)", "W"), ("机会 (Opportunities)", "O"), ("威胁 (Threats)", "T")]:
        items = swto.get(key, swto.get(title, []))
        if items:
            lines.append(f"### {title}\n")
            for i, item in enumerate(items, 1):
                lines.append(f"{i}. {item}")
            lines.append("")

    # 6. 客户风险扫描
    lines.append("## 六、客户风险扫描\n")
    risks = data.get("risks", {})
    lines.append(f"**整体评估**：{risk_badge(risks.get('overall_level', '🟢'))} {risks.get('suggestion', '')}")
    lines.append(f"**数据来源**：{risks.get('source', 'websearch')}\n")
    items = risks.get("items", [])
    if items:
        lines.append("| 风险类别 | 风险项 | 等级 | 说明 | 数据来源 |")
        lines.append("|----------|--------|:----:|------|---------|")
        for r in items:
            level = risk_badge(r.get("level", "🟢"))
            lines.append(f"| {r.get('category','')} | {r.get('item','')} | {level} | {r.get('detail','')} | {r.get('source','')} |")
        lines.append("")
    else:
        lines.append("未发现明显风险。\n")

    # 7. AI 赋能机会洞察
    ao = data.get("ai_opportunities", [])
    if ao:
        lines.append("## 七、AI 赋能机会洞察\n")
        for i, opp in enumerate(ao, 1):
            title = opp.get("title", "")
            desc = opp.get("description", "")
            imp = opp.get("impact_level", "medium")
            roles = opp.get("applicable_roles", "")
            lines.append(f"### 机会 {i}：{title}\n")
            lines.append(f"{desc}\n")
            lines.append(f"- **适用岗位**：{roles}")
            lines.append(f"- **影响度**：{imp}")
            lines.append("")

    # 8. 痛点与需求分析
    lines.append("## 八、痛点与需求分析\n")
    pains = data.get("pain_points", [])
    if pains:
        for i, p in enumerate(pains, 1):
            lines.append(f"### 场景 {i}：{p.get('scenario', '')}\n")
            lines.append(f"- **痛点描述**：{p.get('pain', '')}")
            lines.append(f"- **影响**：{p.get('impact', '')}")
            lines.append(f"- **需求**：{p.get('need', '')}\n")
    else:
        lines.append("（分析中...）\n")

    # 9. 建议方案（匹配表 + 路线图 + ROI）
    lines.append("## 九、建议方案\n")
    matches = data.get("solution_matches", [])
    if matches:
        lines.append("### 问题与方案对照\n")
        lines.append("| 客户痛点 | 对应方案 | 预期价值 |")
        lines.append("|----------|---------|---------|")
        for m in matches:
            lines.append(f"| {m.get('pain','')} | {m.get('solution','')} | {m.get('value','')} |")
        lines.append("")

    roadmap = data.get("implementation_roadmap", [])
    if roadmap:
        lines.append("### 实施路线图\n")
        for ph in roadmap:
            pname = ph.get("name", "")
            timeline = ph.get("timeline", "")
            pid = ph.get("phase", "P")
            details = ph.get("details", [])
            lines.append(f"**{pid} - {pname}**（{timeline}）")
            for d in details:
                lines.append(f"- {d}")
            lines.append("")

    roi = data.get("roi_estimation", {})
    roi_items = roi.get("items", [])
    if roi_items:
        lines.append("### 投入产出预估\n")
        total_inv = roi.get("total_investment", "")
        annual_sav = roi.get("annual_savings", "")
        if total_inv:
            lines.append(f"- **总投入**：{total_inv}")
        if annual_sav:
            lines.append(f"- **预计年化节省**：{annual_sav}")
        lines.append("")
        lines.append("| 项目 | 说明 | 预期效果 |")
        lines.append("|------|------|---------|")
        for r in roi_items:
            lines.append(f"| {r.get('project','')} | {r.get('description','')} | {r.get('effect','')} |")
        lines.append("")

    # 10. AI 扩展思考
    di = data.get("ai_divergent_ideas", [])
    if di:
        lines.append("## 十、AI 扩展思考\n")
        lines.append("> 以下为结合客户行业趋势与我们的能力优势，由 AI 扩展思考出的创新思路，供售前沟通中作为增值话题或差异化提案参考。\n")
        for i, idea in enumerate(di, 1):
            title = idea.get("title", "")
            cat = idea.get("category", "")
            desc = idea.get("description", "")
            rationale = idea.get("rationale", "")
            level = idea.get("innovation_level", "")
            feas = idea.get("feasibility", "")
            tf = idea.get("timeframe", "")
            lines.append(f"### 想法 {i}：{title}\n")
            lines.append(f"- **类别**：{cat}")
            lines.append(f"- **创意描述**：{desc}")
            if rationale:
                lines.append(f"- **思考依据**：{rationale}")
            tags = []
            if level:
                tags.append(level)
            if feas:
                tags.append(f"可行性：{feas}")
            if tf:
                tags.append(tf)
            if tags:
                lines.append(f"- **{' · '.join(tags)}**")
            lines.append("")

    # 11. 竞争格局与差异化定位
    cl = data.get("competitive_landscape", {})
    dims = cl.get("dimensions", [])
    if dims:
        lines.append("## 十一、竞争格局与差异化定位\n")
        positioning = cl.get("our_positioning", "")
        if positioning:
            lines.append(f"> **我们的定位**：{positioning}\n")
        lines.append("| 对比维度 | 我们 | 竞品A | 竞品B |")
        lines.append("|---------|:---:|:----:|:----:|")
        for d in dims:
            lines.append(f"| {d.get('name','')} | {d.get('us','')} | {d.get('competitor_a','')} | {d.get('competitor_b','')} |")
        lines.append("")

    # 12. 客户 FAQ 预测
    lines.append("## 十二、客户 FAQ 预测\n")
    faqs = data.get("faq", [])
    if faqs:
        for i, faq in enumerate(faqs, 1):
            q = faq.get("question", "") if isinstance(faq, dict) else faq
            a = faq.get("answer", "") if isinstance(faq, dict) else ""
            lines.append(f"**Q{i}:** {q}")
            if a:
                lines.append(f"> {a}")
            lines.append("")
    else:
        lines.append("（待生成...）\n")

    # 13. 下一步行动
    lines.append("## 十三、下一步行动\n")
    next_steps = data.get("next_steps", [])
    if next_steps:
        for i, step in enumerate(next_steps, 1):
            lines.append(f"{i}. {step}")
        lines.append("")

    # 备注
    notes = data.get("notes", "")
    if notes:
        lines.append("---\n")
        lines.append(f"*{notes}*\n")

    # 自定义模块
    custom = data.get("custom_sections", [])
    if custom:
        lines.append("---\n")
        for sec in custom:
            lines.append(f"## {sec.get('title', '')}\n")
            lines.append(f"{sec.get('content', '')}\n")

    return "\n".join(lines)


# ──────────────────────────────
# HTML 生成
# ──────────────────────────────

CSS = """
* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
  background: #f5f7fa;
  color: #333;
  line-height: 1.8;
}
.container { max-width: 960px; margin: 0 auto; padding: 20px; }

/* 封面 */
.cover {
  background: linear-gradient(135deg, #1a73e8 0%, #0d47a1 100%);
  color: #fff;
  padding: 80px 40px;
  border-radius: 12px;
  margin-bottom: 32px;
  text-align: center;
}
.cover h1 { font-size: 28px; margin-bottom: 12px; line-height: 1.4; }
.cover .meta { font-size: 14px; opacity: .85; line-height: 1.8; }

/* 章节 */
.section {
  background: #fff;
  border-radius: 12px;
  padding: 28px 32px;
  margin-bottom: 20px;
  box-shadow: 0 1px 4px rgba(0,0,0,.06);
}
.section h2 {
  font-size: 20px;
  color: #1a73e8;
  margin-bottom: 16px;
  padding-bottom: 8px;
  border-bottom: 2px solid #e8f0fe;
  display: flex;
  align-items: center;
  gap: 8px;
}
.section h2 .num {
  display: inline-flex; align-items: center; justify-content: center;
  width: 28px; height: 28px; border-radius: 50%;
  background: #1a73e8; color: #fff;
  font-size: 14px; font-weight: 600;
  flex-shrink: 0;
}
.section h3 {
  font-size: 16px;
  color: #444;
  margin: 16px 0 8px;
}
.section p { margin: 8px 0; color: #555; }

/* 表格 */
table {
  width: 100%;
  border-collapse: collapse;
  margin: 12px 0;
  font-size: 14px;
}
th {
  background: #1a73e8;
  color: #fff;
  padding: 10px 12px;
  text-align: left;
  font-weight: 500;
}
td {
  padding: 10px 12px;
  border-bottom: 1px solid #eee;
}
tr:nth-child(even) td { background: #f8f9fb; }

/* 标签 */
.tag {
  display: inline-block; padding: 2px 12px; border-radius: 15px;
  font-size: 12px; font-weight: 500;
}
.tag-green { background: #e6f9ec; color: #1a7d36; }
.tag-yellow { background: #fff8e1; color: #856404; }
.tag-red { background: #fce4e4; color: #c62828; }

/* 风险 */
.risk-table td:first-child { font-weight: 500; white-space: nowrap; }

/* 卡片网格 */
.card-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 12px 0; }
.card {
  background: #f8f9fb; border-radius: 10px; padding: 16px;
  border-left: 4px solid #1a73e8;
}
.card h4 { font-size: 14px; color: #1a73e8; margin-bottom: 6px; }
.card p { font-size: 13px; color: #555; margin: 0; }

/* 列表 */
ol, ul { padding-left: 20px; margin: 8px 0; }
li { margin: 4px 0; color: #555; }

/* 引用块 */
blockquote {
  border-left: 4px solid #1a73e8;
  background: #f0f6ff;
  padding: 12px 16px;
  margin: 12px 0;
  border-radius: 0 8px 8px 0;
  color: #555;
}
.footer {
  text-align: center; font-size: 12px; color: #999; padding: 20px 0;
}
@media (max-width: 640px) {
  .card-grid { grid-template-columns: 1fr; }
  .cover { padding: 40px 20px; }
  .section { padding: 20px 16px; }
  .opp-grid { grid-template-columns: 1fr; }
  .plan-phase { grid-template-columns: 1fr; }
  .plan-phase .phase-num { margin: 0 auto; }
  .cover-modern { padding: 50px 24px; }
  .star-row { flex-wrap: wrap; }
  .star-row .dim { min-width: 100px; }
}

/* 封面升级 */
.cover-modern {
  background: linear-gradient(135deg, #0f1729 0%, #1a365d 50%, #1a56db 100%);
  color: #fff;
  padding: 100px 60px 80px;
  border-radius: 12px;
  margin-bottom: 32px;
  position: relative;
  overflow: hidden;
  text-align: center;
}
.cover-modern::before {
  content: '';
  position: absolute; top: -50%; right: -20%;
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
  border-radius: 50%;
}
.cover-badge {
  display: inline-block;
  background: rgba(255,255,255,0.15);
  backdrop-filter: blur(10px);
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 14px;
  margin-bottom: 24px;
  border: 1px solid rgba(255,255,255,0.2);
  position: relative; z-index: 1;
}
.cover-modern h1 { font-size: 36px; margin-bottom: 10px; position: relative; z-index: 1; line-height: 1.3; }
.cover-modern .subtitle { font-size: 16px; color: rgba(255,255,255,0.75); margin-bottom: 24px; position: relative; z-index: 1; }
.cover-modern .meta {
  display: flex; justify-content: center; gap: 30px;
  font-size: 13px; color: rgba(255,255,255,0.65);
  position: relative; z-index: 1; flex-wrap: wrap;
}
.cover-modern .meta span { display: flex; align-items: center; gap: 4px; }

/* 星级评分 */
.star-row { display: flex; align-items: center; gap: 10px; padding: 6px 0; }
.star-row .dim { min-width: 140px; font-size: 14px; font-weight: 500; }
.star-row .stars { display: flex; gap: 3px; }
.star-row .stars span { font-size: 16px; }
.star-row .stars .on { color: #f59e0b; }
.star-row .stars .off { color: #e5e7eb; }
.star-row .space { font-size: 13px; color: #555; flex: 1; }

/* 机会卡片 */
.opp-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 12px 0; }
.opp-card {
  background: #fff; border-radius: 10px; padding: 18px 20px;
  border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}
.opp-card h4 { font-size: 15px; margin-bottom: 8px; }
.opp-card p { font-size: 13px; color: #555; line-height: 1.6; }
.opp-card .tags { margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap; }

/* 路线图Phase */
.plan-phase {
  display: grid; grid-template-columns: 80px 1fr; gap: 20px;
  margin-bottom: 20px; padding: 20px 24px;
  background: #fff; border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06); border: 1px solid #e5e7eb;
}
.plan-phase .phase-num {
  width: 64px; height: 64px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-weight: 700; font-size: 20px; color: #fff;
  margin-top: 4px;
}
.plan-phase .phase-content h4 { font-size: 17px; margin-bottom: 8px; }
.plan-phase .phase-content .phase-detail { font-size: 14px; color: #555; }
.plan-phase .phase-content .phase-detail p { margin: 4px 0; }

/* 对比表 */
.compare-table th:first-child { min-width: 130px; }
.compare-table td { text-align: center; }
.compare-table .best { background: #d1fae5 !important; font-weight: 600; color: #065f46; }

/* ROI表 */
.roi-highlight { background: #f0f9ff; padding: 16px 20px; border-radius: 10px; margin: 12px 0; text-align: center; }
.roi-highlight .num { font-size: 24px; font-weight: 700; color: #1a56db; }
.roi-highlight .label { font-size: 13px; color: #6b7280; }

/* AI 扩展思考卡片 */
.divergent-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin: 12px 0; }
.divergent-card {
  background: #fff; border-radius: 12px; padding: 20px;
  border: 1px solid #e5e7eb; box-shadow: 0 1px 4px rgba(0,0,0,0.04);
  position: relative; overflow: hidden;
}
.divergent-card::before {
  content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px;
}
.divergent-card .cat-tag {
  display: inline-block; padding: 2px 10px; border-radius: 12px;
  font-size: 11px; font-weight: 600; margin-bottom: 8px;
}
.divergent-card h4 { font-size: 16px; margin-bottom: 6px; }
.divergent-card p { font-size: 13px; color: #555; line-height: 1.6; margin-bottom: 10px; }
.divergent-card .meta-row { display: flex; gap: 16px; flex-wrap: wrap; font-size: 12px; color: #6b7280; border-top: 1px solid #f3f4f6; padding-top: 10px; margin-top: 10px; }
.divergent-card .meta-row span { display: flex; align-items: center; gap: 4px; }

@media (max-width: 640px) {
  .divergent-grid { grid-template-columns: 1fr; }
}
"""


def render_html(data, my_company):
    """生成 HTML 格式报告"""
    c = data.get("company_name", "目标公司")
    md_content = render_md(data, my_company)

    # 构建 HTML
    sections_html = []

    def esc(val):
        if val is None:
            return ""
        return html_module.escape(str(val))

    # 封面（升级版）
    info_source = data.get("research_source", "websearch")
    source_label = {"qichacha": "企查查", "websearch": "网页搜索", "limited": "有限公开渠道"}
    cm = data.get("cover_meta", {})
    report_id = cm.get("report_id", "")
    classification = cm.get("classification", "")
    subtitle = cm.get("subtitle", "")
    my_name = my_company.get("name", "") if my_company else ""
    meta_items = ""
    meta_items += f'<span>报告日期 {datetime.now().strftime("%Y-%m-%d")}</span>'
    if report_id:
        meta_items += f'<span>编号 {esc(report_id)}</span>'
    if classification:
        meta_items += f'<span>密级 {esc(classification)}</span>'
    if my_name:
        meta_items += f'<span>编制 {esc(my_name)}</span>'
    meta_items += f'<span>数据来源 {source_label.get(info_source, info_source)}</span>'

    subtitle_html = f'<div class="subtitle">{esc(subtitle)}</div>' if subtitle else ""
    cover = f"""<div class="cover-modern">
      <div class="cover-badge">{'🔍 客户洞察 · 售前报告' if report_id else '📋 客户洞察与售前报告'}</div>
      <h1>{esc(c)}</h1>
      {subtitle_html}
      <div class="meta">{meta_items}</div>
    </div>"""

    # 1. 客户概览
    bi = data.get("basic_info", {})
    table_rows = "\n".join(f"<tr><td>{esc(k)}</td><td>{esc(v)}</td></tr>" for k, v in bi.items())
    sections_html.append(f"""<div class="section">
      <h2><span class="num">1</span>客户概览</h2>
      <table><tbody>{table_rows}</tbody></table>
    </div>""")

    # 2. 股东与集团背景
    sh = esc(data.get("shareholder_structure", "暂无数据"))
    sections_html.append(f"""<div class="section">
      <h2><span class="num">2</span>股东与集团背景</h2>
      <p><strong>股权结构</strong>：{sh}</p>
    </div>""")

    # 3. 行业与业务分析
    biz = data.get("business", {})
    biz_html = ""
    if isinstance(biz, dict):
        for k, v in biz.items():
            biz_html += f"<h3>{esc(k)}</h3><p>{esc(v)}</p>"
    else:
        biz_html = f"<p>{esc(biz)}</p>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">3</span>行业与业务分析</h2>
      {biz_html}
    </div>""")

    # 4. 技术能力评估（新增）
    ta = data.get("tech_assessment", [])
    if ta:
        ta_html = ""
        for item in ta:
            dim = esc(item.get("dimension", ""))
            level = item.get("level", 0)
            max_lv = item.get("max_level", 5)
            space = esc(item.get("ai_space", ""))
            stars = ""
            for s in range(max_lv):
                stars += f'<span class="{"on" if s < level else "off"}">★</span>'
            ta_html += f'<div class="star-row"><span class="dim">{dim}</span><span class="stars">{stars}</span><span class="space">{space}</span></div>'
        sections_html.append(f"""<div class="section">
          <h2><span class="num">4</span>技术能力评估</h2>
          {ta_html}
        </div>""")

    # 5. SWTO
    swto = data.get("swto", {})
    swto_map = [
        ("优势 (Strengths)", "S"),
        ("短板 (Weaknesses)", "W"),
        ("机会 (Opportunities)", "O"),
        ("威胁 (Threats)", "T"),
    ]
    swto_html = ""
    for title, key in swto_map:
        items = swto.get(key, swto.get(title, []))
        if items:
            lis = "".join(f"<li>{esc(item)}</li>" for item in items)
            swto_html += f"<h3>{title}</h3><ul>{lis}</ul>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">5</span>SWTO 分析</h2>
      {swto_html}
    </div>""")

    # 6. 风险扫描
    risks = data.get("risks", {})
    ol = risks.get("overall_level", "🟢")
    sug = esc(risks.get("suggestion", ""))
    src = esc(risks.get("source", "websearch"))
    items = risks.get("items", [])
    risk_rows = ""
    for r in items:
        lv = r.get("level", "🟢")
        tag_cls = LEVEL_TAG_CLASS.get(lv, "tag-green")
        level_badge = f'<span class="tag {tag_cls}">{LEVEL_EMOJI.get(lv,lv)} {LEVEL_LABEL.get(lv,"")}</span>'
        risk_rows += f"<tr><td>{esc(r.get('category',''))}</td><td>{esc(r.get('item',''))}</td><td>{level_badge}</td><td>{esc(r.get('detail',''))}</td><td>{esc(r.get('source',''))}</td></tr>"

    risk_body = ""
    if risk_rows:
        risk_body = f"""<table class="risk-table">
          <thead><tr><th>风险类别</th><th>风险项</th><th>等级</th><th>说明</th><th>数据来源</th></tr></thead>
          <tbody>{risk_rows}</tbody>
        </table>"""
    else:
        risk_body = "<p>未发现明显风险。</p>"

    sections_html.append(f"""<div class="section">
      <h2><span class="num">6</span>客户风险扫描</h2>
      <p><strong>整体评估</strong>：<span class="tag {LEVEL_TAG_CLASS.get(ol,'tag-green')}">{LEVEL_EMOJI.get(ol,ol)} {LEVEL_LABEL.get(ol,"")}</span> {sug}</p>
      <p><strong>数据来源</strong>：{src}</p>
      {risk_body}
    </div>""")

    # 7. AI赋能机会洞察（新增）
    ao = data.get("ai_opportunities", [])
    if ao:
        opp_html = ""
        impact_color = {"high": "#059669", "medium": "#2563eb", "low": "#d97706"}
        impact_label = {"high": "高", "medium": "中", "low": "一般"}
        for opp in ao:
            title = esc(opp.get("title", ""))
            desc = esc(opp.get("description", ""))
            imp = opp.get("impact_level", "medium")
            roles = esc(opp.get("applicable_roles", ""))
            color = impact_color.get(imp, "#2563eb")
            lbl = impact_label.get(imp, "")
            role_tag = f'<span class="tag tag-blue">{roles}</span>' if roles else ""
            opp_html += f"""<div class="opp-card" style="border-left:4px solid {color};">
              <h4>🎯 {title}</h4>
              <p>{desc}</p>
              <div class="tags">{role_tag}<span class="tag tag-green">影响度：{lbl}</span></div>
            </div>"""
        sections_html.append(f"""<div class="section">
          <h2><span class="num">7</span>AI 赋能机会洞察</h2>
          <div class="opp-grid">{opp_html}</div>
        </div>""")

    # 8. 痛点与需求分析
    pains = data.get("pain_points", [])
    pain_html = ""
    if pains:
        cards = ""
        for i, p in enumerate(pains, 1):
            cards += f"""<div class="card">
              <h4>场景 {i}：{esc(p.get('scenario',''))}</h4>
              <p><strong>痛点</strong>：{esc(p.get('pain',''))}</p>
              <p><strong>影响</strong>：{esc(p.get('impact',''))}</p>
              <p><strong>需求</strong>：{esc(p.get('need',''))}</p>
            </div>"""
        pain_html = f'<div class="card-grid">{cards}</div>'
    else:
        pain_html = "<p>（分析中...）</p>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">8</span>痛点与需求分析</h2>
      {pain_html}
    </div>""")

    # 9. 建议方案（含匹配表 + 路线图 + ROI）
    sections_html.append(f"""<div class="section">
      <h2><span class="num">9</span>建议方案</h2>""")

    # 方案匹配表
    matches = data.get("solution_matches", [])
    if matches:
        rows = "".join(f"<tr><td>{esc(m.get('pain',''))}</td><td>{esc(m.get('solution',''))}</td><td>{esc(m.get('value',''))}</td></tr>" for m in matches)
        sections_html[-1] += f"""<h3>📋 问题与方案对照</h3><table><thead><tr><th>客户痛点</th><th>对应方案</th><th>预期价值</th></tr></thead><tbody>{rows}</tbody></table>"""

    # 路线图
    roadmap = data.get("implementation_roadmap", [])
    if roadmap:
        sections_html[-1] += '<h3 style="margin-top:24px;">📅 实施路线图</h3>'
        phase_colors = {"green": "#059669", "blue": "#2563eb", "orange": "#d97706"}
        for ph in roadmap:
            pname = esc(ph.get("name", ""))
            timeline = esc(ph.get("timeline", ""))
            pid = ph.get("phase", "P")
            color = phase_colors.get(ph.get("color", "blue"), "#2563eb")
            details = ph.get("details", [])
            roles = esc(ph.get("target_roles", ""))
            invest = esc(ph.get("investment", ""))
            detail_items = "".join(f"<p>• {esc(d)}</p>" for d in details)
            meta_tags = ""
            if roles:
                meta_tags += f'<span class="tag tag-blue">{roles}</span> '
            if invest:
                meta_tags += f'<span class="tag tag-green">{invest}</span>'
            sections_html[-1] += f"""<div class="plan-phase">
              <div class="phase-num" style="background:{color};">{pid}</div>
              <div class="phase-content">
                <h4>{pname} <span style="font-weight:400;font-size:14px;color:#6b7280;">{timeline}</span></h4>
                <div class="phase-detail">{detail_items}<p>{meta_tags}</p></div>
              </div>
            </div>"""

    # ROI 预估
    roi = data.get("roi_estimation", {})
    roi_items = roi.get("items", [])
    if roi_items:
        rows = "".join(f"<tr><td>{esc(r.get('project',''))}</td><td>{esc(r.get('description',''))}</td><td>{esc(r.get('effect',''))}</td></tr>" for r in roi_items)
        total_inv = esc(roi.get("total_investment", ""))
        annual_sav = esc(roi.get("annual_savings", ""))
        roi_header = ""
        if total_inv or annual_sav:
            roi_header = f"""<div class="roi-highlight">
              {'<span><span class="label">总投入</span><br><span class="num">' + total_inv + '</span></span>' if total_inv else ''}
              {'<span style="margin:0 30px;"><span class="label">预计年化节省</span><br><span class="num">' + annual_sav + '</span></span>' if annual_sav else ''}
            </div>"""
        sections_html[-1] += f"""<h3 style="margin-top:24px;">💰 投入产出预估</h3>{roi_header}
          <table><thead><tr><th>项目</th><th>说明</th><th>预期效果</th></tr></thead><tbody>{rows}</tbody></table>"""

    sections_html[-1] += "</div>"

    # 10. AI 扩展思考（新增）
    di = data.get("ai_divergent_ideas", [])
    if di:
        cat_colors = {
            "业务创新": "#2563eb", "技术融合": "#7c3aed", "商业模式": "#059669", "行业颠覆": "#dc2626"
        }
        cat_bg = {
            "业务创新": "#dbeafe", "技术融合": "#ede9fe", "商业模式": "#d1fae5", "行业颠覆": "#fee2e2"
        }
        level_labels = {"渐进式": "💡 渐进式创新", "突破式": "🚀 突破式创新", "颠覆式": "⭐ 颠覆式创新"}
        feas_labels = {"高": "🟢 可行性高", "中": "🟡 可行性中", "低": "🔴 可行性低"}

        grid = ""
        for idea in di:
            title = esc(idea.get("title", ""))
            desc = esc(idea.get("description", ""))
            cat = idea.get("category", "业务创新")
            rationale = esc(idea.get("rationale", ""))
            level = idea.get("innovation_level", "渐进式")
            feas = idea.get("feasibility", "中")
            tf = idea.get("timeframe", "")
            color = cat_colors.get(cat, "#2563eb")
            bg = cat_bg.get(cat, "#dbeafe")
            lvl_label = level_labels.get(level, level)
            feas_label = feas_labels.get(feas, feas)
            meta_items = f'<span>{lvl_label}</span>'
            if feas:
                meta_items += f'<span>{feas_label}</span>'
            if tf:
                meta_items += f'<span>📅 {esc(tf)}</span>'
            rationale_html = f'<p><strong>思考依据</strong>：{rationale}</p>' if rationale else ""
            grid += f"""<div class="divergent-card" style="border-left-color:{color};">
              <div class="cat-tag" style="background:{bg};color:{color};">{esc(cat)}</div>
              <h4>{title}</h4>
              <p>{desc}</p>
              {rationale_html}
              <div class="meta-row">{meta_items}</div>
            </div>"""

        sections_html.append(f"""<div class="section">
          <h2><span class="num">10</span>AI 扩展思考</h2>
          <p style="font-size:14px;color:#6b7280;margin-bottom:16px;">以下为结合客户行业趋势与我们的能力优势，由 AI 扩展思考出的创新思路，供售前沟通中作为增值话题或差异化提案参考。</p>
          <div class="divergent-grid">{grid}</div>
        </div>""")

    # 11. 竞争格局与差异化定位（新增）
    cl = data.get("competitive_landscape", {})
    dims = cl.get("dimensions", [])
    if dims:
        positioning = esc(cl.get("our_positioning", ""))
        header = f'<p style="margin-bottom:12px;font-size:14px;color:#555;"><strong>我们的定位</strong>：{positioning}</p>' if positioning else ""
        rows = "".join(f"<tr><td>{esc(d.get('name',''))}</td><td>{esc(d.get('us',''))}</td><td>{esc(d.get('competitor_a',''))}</td><td>{esc(d.get('competitor_b',''))}</td></tr>" for d in dims)
        sections_html.append(f"""<div class="section">
          <h2><span class="num">11</span>竞争格局与差异化定位</h2>
          {header}
          <table class="compare-table"><thead><tr><th>对比维度</th><th>我们</th><th>竞品A</th><th>竞品B</th></tr></thead><tbody>{rows}</tbody></table>
        </div>""")

    # 11. FAQ
    faqs = data.get("faq", [])
    faq_html = ""
    if faqs:
        for i, faq in enumerate(faqs, 1):
            q = faq.get("question", "") if isinstance(faq, dict) else faq
            a = faq.get("answer", "") if isinstance(faq, dict) else ""
            faq_html += f"<h3>Q{i}: {esc(q)}</h3>"
            if a:
                faq_html += f"<blockquote>{esc(a)}</blockquote>"
    else:
        faq_html = "<p>（待生成...）</p>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">12</span>客户 FAQ 预测</h2>
      {faq_html}
    </div>""")

    # 10. 下一步
    steps = data.get("next_steps", [])
    steps_html = ""
    if steps:
        lis = "".join(f"<li>{esc(s)}</li>" for s in steps)
        steps_html = f"<ol>{lis}</ol>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">13</span>下一步行动</h2>
      {steps_html}
    </div>""")

    # 备注
    notes = data.get("notes", "")
    notes_html = ""
    if notes:
        notes_html = f'<div class="section" style="background:#fff8e1;"><p><em>{esc(notes)}</em></p></div>'

    # 自定义模块
    custom = data.get("custom_sections", [])
    custom_html = ""
    for sec in custom:
        custom_html += f"""<div class="section">
          <h2>{esc(sec.get('title',''))}</h2>
          <p>{esc(sec.get('content',''))}</p>
        </div>"""

    company_footer = ""
    if my_company and my_company.get("name"):
        company_footer = f'<p><strong>{esc(my_company["name"])}</strong></p>'
    full_html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(c)} - 客户洞察与售前咨询报告</title>
<style>{CSS}</style>
</head>
<body>
<div class="container">
{cover}
{"".join(sections_html)}
{notes_html}
{custom_html}
<div class="footer">
{company_footer}
<p>本报告仅供内部业务使用，所含客户信息来源于公开渠道，仅供参考。</p>
<p>© {datetime.now().strftime('%Y')} wx-customer-insight-report</p>
</div>
</div>
</body>
</html>"""
    return full_html


# ──────────────────────────────
# 主入口
# ──────────────────────────────

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 generate_report.py <report_data.json> [config.json] [output_dir]")
        sys.exit(1)

    report_path = sys.argv[1]
    config_path = sys.argv[2] if len(sys.argv) > 2 else default_skill_userdata("wx-customer-insight-report", "config.json")
    output_dir = sys.argv[3] if len(sys.argv) > 3 else os.getcwd()

    # 打印实际路径（调试时可确认跨平台兼容性）
    print(f"[INFO] 报告数据: {report_path}")
    print(f"[INFO] 配置文件: {config_path}")
    print(f"[INFO] 输出目录: {output_dir}")

    # 读取数据
    report_data = read_json(report_path)
    config_data = read_json(config_path)

    if not report_data:
        print("[ERROR] 报告数据为空，无法生成")
        sys.exit(1)

    my_company = config_data.get("my_company", {})
    company_name = report_data.get("company_name", "目标公司")
    slug = make_slug(company_name)

    os.makedirs(output_dir, exist_ok=True)

    # 生成 MD
    md = render_md(report_data, my_company)
    md_path = os.path.join(output_dir, f"{slug}-客户洞察与售前报告.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md)
    print(f"[OK] MD 报告: {md_path}")

    # 生成 HTML
    html = render_html(report_data, my_company)
    html_path = os.path.join(output_dir, f"{slug}-客户洞察与售前报告.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[OK] HTML 报告: {html_path}")


if __name__ == "__main__":
    main()
